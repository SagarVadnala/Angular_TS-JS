import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class FileService {
  constructor(private httpClient: HttpClient) { }

  UploadFile(file: any): Observable<HttpResponse<any>> {
    let myheaders  = new HttpHeaders({'Access-Control-Allow-Origin':'*', 'Access-Control-Allow-Methods':'GET,POST,OPTIONS,DELETE,PUT'})
    return this.httpClient.post<any>(environment.apiAddress + '/course/uploadfile', file, { headers: myheaders, observe: 'response' });
  }
}
