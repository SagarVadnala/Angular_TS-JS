import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styles: [],
  standalone: true,
})
export class CoursesComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
