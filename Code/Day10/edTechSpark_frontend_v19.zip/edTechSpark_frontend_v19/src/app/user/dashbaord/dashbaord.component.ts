import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashbaord',
  templateUrl: './dashbaord.component.html',
  styles: [],
  standalone: true,
})
export class DashbaordComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
