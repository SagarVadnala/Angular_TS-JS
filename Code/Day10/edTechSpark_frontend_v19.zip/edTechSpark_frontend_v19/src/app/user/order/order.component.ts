import { Component, inject, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Order } from '../..//models/order';
import { OrderService } from '../../services/order.service';
import { NgFor, CurrencyPipe } from '@angular/common';
import * as env from '../../../environments/environment';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styles: [],
  standalone: true,
  imports: [NgFor, RouterLink, CurrencyPipe],
})
export class OrderComponent implements OnInit {
  order: Order | any;
  private orderService = inject(OrderService);
  private route = inject(ActivatedRoute);
  imageServer: string = ''
  constructor() {
    this.imageServer = env.environment.imageServer;
  }

  ngOnInit(): void {
    this.route.params.subscribe((params) => {
      let id = params['id'];
      this.orderService.GetOrderDetails(id).subscribe((res) => {
        if (res.status == 200 && res.body != null) {
          this.order = res.body;
        }
      });
    });
  }
}
