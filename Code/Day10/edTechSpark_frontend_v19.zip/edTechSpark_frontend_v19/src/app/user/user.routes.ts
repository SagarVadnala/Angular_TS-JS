import { Routes } from '@angular/router';
import { DashbaordComponent } from './dashbaord/dashbaord.component';
import { OrdersComponent } from './orders/orders.component';
import { OrderComponent } from './order/order.component';
import { CoursesComponent } from './courses/courses.component';
import { UserLayoutComponent } from './shared/user-layout.component';

export const USER_ROUTES: Routes = [
  {
    path: '',
    component: UserLayoutComponent,
    children: [
      { path: '', component: DashbaordComponent },
      { path: 'orders', component: OrdersComponent },
      { path: 'order/:id', component: OrderComponent },
      { path: 'courses', component: CoursesComponent },
    ],
  },
];
