import { Component } from '@angular/core';
import { HeaderComponent } from './header/header.component';
import { RouterOutlet } from '@angular/router';
import { FooterComponent } from './footer/footer.component';

@Component({
  selector: 'app-user-layout',
  templateUrl: './user-layout.component.html',
  styles: [],
  standalone: true,
  imports: [HeaderComponent, RouterOutlet, FooterComponent],
})
export class UserLayoutComponent {
  constructor() {}
}
