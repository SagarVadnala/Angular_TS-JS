import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unauthorize',
  templateUrl: './unauthorize.component.html',
  styles: [],
  standalone: true,
})
export class UnauthorizeComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
