import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-fullsize-layout',
  templateUrl: './fullsize-layout.component.html',
  styles: [],
  standalone: true,
  imports: [RouterOutlet],
})
export class FullsizeLayoutComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
