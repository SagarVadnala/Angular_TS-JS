import { Component } from '@angular/core';
import { CourselistComponent } from '../shared/courselist/courselist.component';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styles: [],
  standalone: true,
  imports: [CourselistComponent],
})
export class CoursesComponent {}
