import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Course } from '../../models/course';
import { CatalogService } from '../../services/catalog.service';
import { HeaderComponent } from '../shared/header/header.component';
import { NgIf, NgFor, CurrencyPipe } from '@angular/common';
import { FooterComponent } from '../shared/footer/footer.component';
import { SafePipe } from '../../shared/safe.pipe';
import * as env from '../../../environments/environment';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styles: [],
  standalone: true,
  imports: [
    HeaderComponent,
    RouterLink,
    NgIf,
    NgFor,
    FooterComponent,
    CurrencyPipe,
    SafePipe,
  ],
})
export class CourseComponent implements OnInit {
  name: string | any;
  course: Course | any;
  imageServer: string = ''
  constructor(private catalogService: CatalogService,private route: ActivatedRoute) 
  {
    this.imageServer = env.environment.imageServer;
  }

  ngOnInit(): void {
    this.route.params.subscribe((params) => {
      this.name = params['name'];
      this.catalogService.GetCourse(this.name).subscribe((res) => {
        if (res.status == 200) {
          this.course = res.body;
        }
      });
    });
  }

  AddToCart( id: number, name: string,  unitPrice: number, quantity: number,  image: string,) 
  {

  }

  BuyNow( id: number,  name: string, unitPrice: number, quantity: number, image: string,) {

  }
}
