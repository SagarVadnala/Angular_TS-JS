import { Component } from '@angular/core';
import { HeaderComponent } from '../shared/header/header.component';
import { CourselistComponent } from '../shared/courselist/courselist.component';
import { FooterComponent } from '../shared/footer/footer.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  standalone: true,
  imports: [HeaderComponent, CourselistComponent, FooterComponent],
})
export class HomeComponent {}
