import { Component } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, NgIf],
})
export class SignupComponent {
  userForm: FormGroup;
  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
  ) {
    this.userForm = this.fb.group({
      name: [null, Validators.required],
      email: [null, [Validators.required, Validators.email]],
      password: [null, Validators.required],
      confirmPassword: [null, Validators.required],
      phoneNumber: [null, Validators.required],
      role: ["User"]
    });
  }

  userSignUp() {
    if (this.userForm.valid) {
      if (this.userForm.get('role').value === 'Admin') {
        this.authService.AdminSignUp(this.userForm.value).subscribe((res) => {
          if (res.status == 201) {
            this.router.navigate(['/login']);
          }
        });
      }
      else {
        this.authService.UserSignUp(this.userForm.value).subscribe((res) => {
          if (res.status == 201) {
            this.router.navigate(['/login']);
          }
        });
      }
    }
  }
}
