import { Component } from '@angular/core';

@Component({
  selector: 'app-notfound',
  templateUrl: './notfound.component.html',
  styles: [],
  standalone: true,
})
export class NotfoundComponent {}
