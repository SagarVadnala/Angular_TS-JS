import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Pipe({
  name: 'safe',
  standalone: true,
})
export class SafePipe implements PipeTransform {
  constructor(private santizer: DomSanitizer) {}
  transform(value: any): any {
    return this.santizer.bypassSecurityTrustResourceUrl(value);
  }
}
