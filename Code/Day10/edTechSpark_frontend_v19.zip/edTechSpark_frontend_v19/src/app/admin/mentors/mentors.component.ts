import { Component, OnInit } from '@angular/core';
import { Mentor } from '../../models/mentor';
import { MentorService } from '../../services/mentor.service';
import { RouterLink } from '@angular/router';
import { NgFor } from '@angular/common';
import * as env from '../../../environments/environment';


@Component({
  selector: 'app-mentors',
  templateUrl: './mentors.component.html',
  standalone: true,
  imports: [RouterLink, NgFor],
})
export class MentorsComponent implements OnInit {
  mentors: Mentor[] | any;
  imageServer:string = '';
  constructor(private mentorService: MentorService) 
  {
    this.imageServer = env.environment.imageServer;
  }

  ngOnInit(): void {
    this.mentorService.GetMentors().subscribe((res) => {
      this.mentors = res.body;
    });
  }
  deleteMentor(id: number) {
    this.mentorService.DeleteMentor(id).subscribe((res) => {
      if (res.status == 200) {
        location.reload();
      }
    });
  }
}
