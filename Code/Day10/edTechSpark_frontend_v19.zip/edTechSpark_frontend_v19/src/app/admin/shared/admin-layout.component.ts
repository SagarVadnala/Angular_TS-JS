import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from './header/header.component';
import { RouterOutlet } from '@angular/router';
import { FooterComponent } from './footer/footer.component';

@Component({
  selector: 'app-admin-layout',
  templateUrl: './admin-layout.component.html',
  styles: [],
  standalone: true,
  imports: [HeaderComponent, RouterOutlet, FooterComponent],
})
export class AdminLayoutComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
