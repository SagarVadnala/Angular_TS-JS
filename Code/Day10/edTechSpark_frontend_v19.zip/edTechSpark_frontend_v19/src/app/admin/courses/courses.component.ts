import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { Course } from '../../models/course';
import { CourseService } from '../../services/course.service';
import { NgFor } from '@angular/common';
import * as env from '../../../environments/environment';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  standalone: true,
  imports: [RouterLink, NgFor],
})
export class CoursesComponent implements OnInit {
  courses: Course[] | undefined;
  imageServer: string;
  constructor(private courseService: CourseService,private router: Router) 
  {
      this.imageServer = env.environment.imageServer;
  }

  ngOnInit() {
    this.courseService.GetCourses().subscribe((res) => {
      if (res.status == 200 && res.body != null) {
        this.courses = res.body;
      }
    });
  }
  deleteCourse(id: number) {
    this.courseService.DeleteCourse(id).subscribe((res) => {
      if (res.status == 200) {
        location.reload();
      }
    });
  }
}
