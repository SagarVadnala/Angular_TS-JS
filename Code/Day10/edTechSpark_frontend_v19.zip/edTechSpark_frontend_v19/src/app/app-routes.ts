import { Routes } from '@angular/router';
import { adminAuthGuard } from './guards/admin-auth.guard';
import { userAuthGuard } from './guards/user-auth.guard';

export const routes: Routes = [
  {
    path: 'admin',
    canActivate: [adminAuthGuard],
    loadChildren: () =>import('./admin/admin.routes').then((m) => m.ADMIN_ROUTES),
  },
  {
    path: 'user',
    canActivate: [userAuthGuard],
    loadChildren: () => import('./user/user.routes').then((m) => m.USER_ROUTES),
  },
  {
    path: '',
    loadChildren: () =>
      import('./public/public.routes').then((m) => m.PUBLIC_ROUTES),
  },
];
