import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { serverInterceptor } from './app/interceptors/server.interceptor';
import { ErrorHandler, importProvidersFrom } from '@angular/core';
import { ExceptionHandler } from './app/shared/exceptionhandler';
import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { provideRouter } from '@angular/router';
import { routes } from './app/app-routes';

bootstrapApplication(AppComponent, {
  providers: [
    provideRouter(routes),
    provideHttpClient(withInterceptors([serverInterceptor])),
    { provide: ErrorHandler, useClass: ExceptionHandler },
  ],
}).catch((err) => console.error(err));
