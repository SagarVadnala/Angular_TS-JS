"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const istudent_1 = require("./istudent");
const person_1 = require("./person");
class Student {
    studentId;
    constructor(sid) {
        this.studentId = sid;
        (0, istudent_1.callMe)();
    }
    showData() {
        let person = new person_1.Person();
        console.log(`StudentId=${this.studentId}`);
    }
}
