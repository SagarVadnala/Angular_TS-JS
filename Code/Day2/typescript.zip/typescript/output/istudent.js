"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PI = void 0;
exports.callMe = callMe;
function callMe() {
    console.log('Call me');
}
exports.PI = 3.14;
