"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function getData(data) {
    let p = new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log('Step 2');
            if (data.length > 10) {
                resolve("Data is correct:" + data);
            }
            else {
                reject("Error:Data length is incorrect");
            }
        }, 3000);
    });
    return p;
}
function getData1(data) {
    let p = new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log('Step 2.1');
            if (data.length > 10) {
                resolve("1:Data is correct:" + data);
            }
            else {
                reject("1:Error:Data length is incorrect");
            }
        }, 3000);
    });
    return p;
}
async function callFunc() {
    console.log('Step 1');
    let result1 = await getData("pradeep shet");
    console.log("Result 1=" + result1);
    let result2 = await getData1("pradeep shet");
    console.log("Result 2=" + result2);
    console.log('Step 3');
}
callFunc();
// console.log('Step 1');
// getData("Pradeep Shet")
// .then(resp => {
//     console.log(resp);
// }).catch(error => {
//     console.log(error);
// });
// console.log('Step 3');
class StaticClass {
    static mycall() {
        console.log("Static method called");
    }
}
StaticClass.mycall();
