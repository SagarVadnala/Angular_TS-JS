import IStudent, {PI, callMe} from "./istudent";
import { Person } from "./person";

class Student implements IStudent {
    studentId: number;

    constructor(sid: number) {
        this.studentId = sid;
        callMe();
    }

    showData(): void {
        let person = new Person();
        console.log(`StudentId=${this.studentId}`);
    }
}

